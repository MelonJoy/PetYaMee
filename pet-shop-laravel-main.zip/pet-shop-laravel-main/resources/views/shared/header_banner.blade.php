<section class="w-full mx-auto bg-nordic-gray-light flex pt-12 md:pt-0 md:items-center bg-cover bg-right"
    style="max-width:1600px; height: 32rem; background-image: url('https://rb.gy/omxlcq');">

    <div class="container mx-auto">

        <div class="flex flex-col w-full lg:w-1/2 justify-center items-start  px-6 tracking-wide">
            {{-- <h1 class="text-slate-600 text-6xl my-4 font-bold ">Love Conquers All</h1> --}}
        </div>

    </div>

</section>
