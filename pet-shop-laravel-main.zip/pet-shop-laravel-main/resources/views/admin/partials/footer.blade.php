<footer class="w-full bg-white text-right p-4">
    Built by <a href="#" class="underline">Pets Corporation</a>.
</footer>
